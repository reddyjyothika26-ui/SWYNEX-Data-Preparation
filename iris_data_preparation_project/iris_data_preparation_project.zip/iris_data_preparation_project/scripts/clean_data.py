from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "iris_raw_messy.csv"
OUTPUT = ROOT / "data" / "iris_cleaned.csv"

df = pd.read_csv(INPUT, dtype=str)

# 1. Standardize blank strings and common missing-value markers.
missing_markers = ["", "NA", "N/A", "missing", "None", "null"]
df = df.replace(missing_markers, pd.NA)
df = df.replace(r"^\s*$", pd.NA, regex=True)

# 2. Convert measurement columns to numeric. Invalid strings become missing.
numeric_cols = [
    "sepal_length_cm", "sepal_width_cm",
    "petal_length_cm", "petal_width_cm"
]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col].astype("string").str.strip(), errors="coerce")

# 3. Standardize species labels.
df["species"] = (
    df["species"].astype("string")
    .str.strip()
    .str.lower()
    .replace({
        "iris-setosa": "Iris-setosa",
        "iris-versicolor": "Iris-versicolor",
        "iris-virginica": "Iris-virginica"
    })
)

# 4. Fill missing numeric measurements with the median of that column.
# Assumption: median is robust to extreme values and preserves all rows.
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

# 5. Use a categorical dtype for the target column.
df["species"] = df["species"].astype("category")

# 6. Validate and export.
assert df.isna().sum().sum() == 0, "Missing values remain after cleaning."
assert df["species"].isin(
    ["Iris-setosa", "Iris-versicolor", "Iris-virginica"]
).all(), "Unexpected species label found."

df.to_csv(OUTPUT, index=False)
print(f"Saved cleaned dataset to: {OUTPUT}")
print("\nData types:")
print(df.dtypes)
print("\nMissing values after cleaning:")
print(df.isna().sum())
print(f"\nRows: {len(df)} | Columns: {len(df.columns)}")
