# Iris Dataset — Data Preparation Internship Task

## Project overview
This beginner-friendly project demonstrates a reproducible data-preparation workflow using the public Iris flower dataset. The original dataset contains 150 rows, four numeric flower measurements (in centimetres), and a species label.

**Important:** `iris_reference_original.csv` is the unmodified reference data. `iris_raw_messy.csv` is a practice copy in which a small number of missing-value markers, invalid numeric strings, whitespace, and inconsistent species labels were deliberately introduced. These issues were added for this exercise and are not present in the original UCI dataset.

## Dataset source
- UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/53/iris
- Citation: Fisher, R. (1936). *Iris* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56C76
- License: CC BY 4.0. Give appropriate attribution when redistributing the dataset.

## Files
- `data/iris_raw_messy.csv` — intentionally messy practice input.
- `data/iris_reference_original.csv` — original clean reference dataset.
- `data/iris_cleaned.csv` — cleaned output produced by the script/notebook.
- `notebooks/data_preparation.ipynb` — step-by-step notebook.
- `scripts/clean_data.py` — repeatable cleaning script.
- `requirements.txt` — Python dependencies.

## Preparation steps
1. Load the raw CSV as strings so mixed types are visible.
2. Standardize blank cells and common missing-value markers.
3. Convert the four measurement columns to numeric; unparseable values become missing.
4. Normalize species labels by trimming whitespace and standardizing capitalization.
5. Fill missing measurements with each column's median.
6. Convert `species` to a categorical data type.
7. Validate missing values, species labels, and positive measurement values.
8. Export the cleaned data.

## Assumptions and limitations
- Median imputation is used because it is simple and relatively robust to extreme values. This is a teaching choice, not necessarily the best choice for every dataset.
- Invalid measurement text is treated as missing rather than interpreted by guesswork.
- Species labels are standardized only when they match the three known classes.
- No rows are removed, to preserve the small dataset for practice.
- The original Iris dataset does not contain missing values according to UCI; the issues in the messy copy were injected for this exercise.
- This is a data-cleaning exercise, not a predictive model.

## Run locally
```bash
pip install -r requirements.txt
python scripts/clean_data.py
```

Or open `notebooks/data_preparation.ipynb` in Jupyter Notebook or Google Colab.

## Suggested GitHub repository description
A beginner data-preparation project using the public Iris dataset, demonstrating missing-value handling, type conversion, category standardization, validation, and export.
